const mazeContainer = document.getElementById("maze");
const rows = 10;
const cols = 10;
const start = [0, 0];
const end = [9, 9];
let maze = [];
let delay = 100; // Default speed

function updateSpeed() {
  delay = parseInt(document.getElementById("speed").value);
}

function sleep(ms) {
  return new Promise(res => setTimeout(res, ms));
}

function generateRandomMaze() {
  maze = [];
  for (let r = 0; r < rows; r++) {
    const row = [];
    for (let c = 0; c < cols; c++) {
      if ((r === start[0] && c === start[1]) || (r === end[0] && c === end[1])) {
        row.push(0);
      } else {
        row.push(Math.random() < 0.3 ? 1 : 0); // 30% chance wall
      }
    }
    maze.push(row);
  }
  createMaze();
}

function createMaze() {
  mazeContainer.innerHTML = '';
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const cell = document.createElement("div");
      cell.className = "cell";
      if (maze[r][c] === 1) cell.classList.add("wall");
      if (r === start[0] && c === start[1]) cell.classList.add("start");
      if (r === end[0] && c === end[1]) cell.classList.add("end");
      cell.id = `cell-${r}-${c}`;
      mazeContainer.appendChild(cell);
    }
  }
}

async function solveMazeDFS() {
  createMaze();
  const visited = Array.from({ length: rows }, () => Array(cols).fill(false));
  const parent = Array.from({ length: rows }, () => Array(cols).fill(null));
  const stack = [start];

  while (stack.length > 0) {
    const [r, c] = stack.pop();
    if (r < 0 || c < 0 || r >= rows || c >= cols || maze[r][c] === 1 || visited[r][c]) continue;

    visited[r][c] = true;
    const cell = document.getElementById(`cell-${r}-${c}`);
    if (!cell.classList.contains("start") && !cell.classList.contains("end"))
      cell.classList.add("visited-dfs");

    if (r === end[0] && c === end[1]) {
      await drawFinalPath(parent, end);
      return;
    }

    await sleep(delay);

    const directions = [
      [r + 1, c],
      [r - 1, c],
      [r, c + 1],
      [r, c - 1],
    ];

    for (let [nr, nc] of directions) {
      if (nr >= 0 && nc >= 0 && nr < rows && nc < cols && !visited[nr][nc] && maze[nr][nc] === 0) {
        stack.push([nr, nc]);
        if (!parent[nr][nc]) parent[nr][nc] = [r, c];
      }
    }
  }
}

async function solveMazeBFS() {
  createMaze();
  const visited = Array.from({ length: rows }, () => Array(cols).fill(false));
  const parent = Array.from({ length: rows }, () => Array(cols).fill(null));
  const queue = [start];

  while (queue.length > 0) {
    const [r, c] = queue.shift();
    if (r < 0 || c < 0 || r >= rows || c >= cols || maze[r][c] === 1 || visited[r][c]) continue;

    visited[r][c] = true;
    const cell = document.getElementById(`cell-${r}-${c}`);
    if (!cell.classList.contains("start") && !cell.classList.contains("end"))
      cell.classList.add("visited-bfs");

    if (r === end[0] && c === end[1]) {
      await drawFinalPath(parent, end);
      return;
    }

    await sleep(delay);

    const directions = [
      [r + 1, c],
      [r - 1, c],
      [r, c + 1],
      [r, c - 1],
    ];

    for (let [nr, nc] of directions) {
      if (nr >= 0 && nc >= 0 && nr < rows && nc < cols && !visited[nr][nc] && maze[nr][nc] === 0) {
        queue.push([nr, nc]);
        if (!parent[nr][nc]) parent[nr][nc] = [r, c];
      }
    }
  }
}

async function drawFinalPath(parent, end) {
  let path = [];
  let current = end;

  while (current) {
    path.push(current);
    current = parent[current[0]][current[1]];
  }

  path.reverse();

  for (let [r, c] of path) {
    const cell = document.getElementById(`cell-${r}-${c}`);
    if (!cell.classList.contains("start") && !cell.classList.contains("end")) {
      cell.classList.remove("visited-dfs", "visited-bfs");
      cell.classList.add("final-path");
      await sleep(50);
    }
  }
}

// Display default empty maze on load
function defaultMaze() {
  maze = Array.from({ length: rows }, () =>
    Array.from({ length: cols }, () => 0)
  );
  maze[3][3] = 1;
  maze[2][2] = 1;
  maze[4][4] = 1;
  createMaze();
}

defaultMaze();
